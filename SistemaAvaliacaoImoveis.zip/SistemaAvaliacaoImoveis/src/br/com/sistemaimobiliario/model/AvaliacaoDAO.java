/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.sistemaimobiliario.model;

/**
 *
 * @author Artuu
 */
import java.sql.*;
import java.util.*;

public class AvaliacaoDAO {
    
    // Método para conectar ao banco de dados
    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/sistema_imobiliario";  // URL do banco
        String user = "root";  // Seu usuário do banco de dados
        String password = "root";  // Sua senha do banco de dados
        return DriverManager.getConnection(url, user, password);
    }

    // Método para salvar a avaliação no banco de dados
    public void salvarAvaliacao(Avaliacao avaliacao) throws SQLException {
        String sql = "INSERT INTO avaliacoes (id_propriedade, nota, comentario) VALUES (?, ?, ?)";

        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Preenche os parâmetros da consulta SQL
            stmt.setInt(1, avaliacao.getIdPropriedade());  // ID da propriedade
            stmt.setInt(2, avaliacao.getNota());            // Nota da avaliação
            stmt.setString(3, avaliacao.getComentario());   // Comentário da avaliação

            // Executa a consulta de inserção
            stmt.executeUpdate();
        }
    }

    // Método para buscar as avaliações por id da propriedade
    public List<Avaliacao> buscarAvaliacoesPorPropriedade(int idPropriedade) throws SQLException {
        String sql = "SELECT nota, comentario FROM avaliacoes WHERE id_propriedade = ?";
        List<Avaliacao> avaliacoes = new ArrayList<>();

        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPropriedade);
            ResultSet rs = stmt.executeQuery();

            // Adiciona as avaliações encontradas na lista
            while (rs.next()) {
                int nota = rs.getInt("nota");
                String comentario = rs.getString("comentario");
                Avaliacao avaliacao = new Avaliacao(idPropriedade, nota, comentario);
                avaliacoes.add(avaliacao);
            }
        }
        return avaliacoes;
    }
}

