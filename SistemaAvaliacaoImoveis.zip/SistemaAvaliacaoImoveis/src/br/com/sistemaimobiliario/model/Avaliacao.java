/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.sistemaimobiliario.model;

/**
 *
 * @author Artuu
 */
public class Avaliacao {
    private int idPropriedade;  // ID da propriedade
    private int nota;
    private String comentario;

    // Construtor da classe Avaliacao
    public Avaliacao(int idPropriedade, int nota, String comentario) {
        this.idPropriedade = idPropriedade;  // Armazena o ID da propriedade
        this.nota = nota;  // Armazena a nota
        this.comentario = comentario;  // Armazena o comentário
    }

    // Getters e Setters (se necessário)
    public int getIdPropriedade() {
        return idPropriedade;
    }

    public int getNota() {
        return nota;
    }

    public String getComentario() {
        return comentario;
    }
}
