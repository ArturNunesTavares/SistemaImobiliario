package br.com.sistemaimobiliario.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class NovoUsuarioDAO {


    // Método para conectar ao banco de dados
    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/sistema_imobiliario";  
        String user = "root";  // Seu usuário do banco de dados
        String password = "root";  // Sua senha do banco de dados
        return DriverManager.getConnection(url, user, password);
    }

    // Método para cadastrar o usuário no banco
    public void CadastrarUsuario(NovoUsuario novoUsuario) throws SQLException {
        String sql = "INSERT INTO usuario (nome, email, senha, tipo_usuario) VALUES (?, ?, ?, ?)";

        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Preenche os parâmetros da consulta SQL com os dados do usuário
            stmt.setString(1, novoUsuario.getNome());
            stmt.setString(2, novoUsuario.getEmail());
            stmt.setString(3, novoUsuario.getSenha());
            stmt.setString(4, novoUsuario.getTipoUsuario());  // Tipo do usuário, pode ser 'Avaliador' ou 'Corretor'

            // Executa a consulta de inserção
            stmt.executeUpdate();
        }
    }
}
