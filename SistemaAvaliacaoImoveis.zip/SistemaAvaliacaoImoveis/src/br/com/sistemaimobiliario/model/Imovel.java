/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.sistemaimobiliario.model;

/**
 *
 * @author Artuu
 */
public class Imovel {
    
    private double CNPJ;
    private String email;
    private String telefone;
    private String endereco;
    private String cidade;
    private String estado;
    private double areaimovel;
    private double valordiaria;
    private String caracteristicas;
    
    
    public Imovel(double CNPJ, String email, String telefone, String endereco, String cidade, 
                  String estado, double areaimovel, double valordiaria, String caracteristicas) {
        this.CNPJ = CNPJ;
        this.email = email;
        this.telefone = telefone;
        this.endereco = endereco;
        this.cidade = cidade;
        this.estado = estado;
        this.areaimovel = areaimovel;
        this.valordiaria = valordiaria;
        this.caracteristicas = caracteristicas;
    }

    /**
     * @return the CNPJ
     */
    public double getCNPJ() {
        return CNPJ;
    }

    /**
     * @param CNPJ the CNPJ to set
     */
    public void setCNPJ(double CNPJ) {
        this.CNPJ = CNPJ;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * @return the cidade
     */
    public String getCidade() {
        return cidade;
    }

    /**
     * @param cidade the cidade to set
     */
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * @return the areaimovel
     */
    public double getAreaimovel() {
        return areaimovel;
    }

    /**
     * @param areaimovel the areaimovel to set
     */
    public void setAreaimovel(double areaimovel) {
        this.areaimovel = areaimovel;
    }

    /**
     * @return the valordiaria
     */
    public double getValordiaria() {
        return valordiaria;
    }

    /**
     * @param valordiaria the valordiaria to set
     */
    public void setValordiaria(double valordiaria) {
        this.valordiaria = valordiaria;
    }

    /**
     * @return the caracteristicas
     */
    public String getCaracteristicas() {
        return caracteristicas;
    }

    /**
     * @param caracteristicas the caracteristicas to set
     */
    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }
    
}
