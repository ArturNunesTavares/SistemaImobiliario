/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package br.com.imoveis.sistemaimobiliario;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Artuu
 */
public class ViewCadastroProp extends javax.swing.JFrame {
    
      // Conexão com o banco de dados
    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/sistema_imobiliario"; 
        String user = "root";  
        String password = "root"; 
        return DriverManager.getConnection(url, user, password);
    }

    private void cadastrarPropriedade() {
        System.out.println("Método cadastrarPropriedade foi chamado");

        // Pegue os valores dos campos de texto
        BigInteger cnpj = null;
        try {
            cnpj = new BigInteger(TFcpfcnpj.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "CNPJ inválido. Certifique-se de que o campo CNPJ contém apenas números.");
            return;
        }
        
        String email = TFemailcadastroimovel.getText().trim();
        String telefone = TFtelefone.getText().trim();
        String endereco = TFendereco.getText().trim();
        String cidade = TFcidade.getText().trim();
        String estado = TFestado.getText().trim();
        
        double areaImovel;
        try {
            areaImovel = Double.parseDouble(TFarea.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Área do imóvel deve ser um número válido.");
            return;
        }

        double valorDiaria;
        try {
            valorDiaria = Double.parseDouble(TFvalordiaria.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Valor da diária deve ser um número válido.");
            return;
        }

        String caracteristicas = TPcaracteristicas.getText().trim();

        // Verificar se campos obrigatórios não estão vazios
        if (email.isEmpty() || telefone.isEmpty() || endereco.isEmpty() || cidade.isEmpty() || estado.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Campos obrigatórios não podem estar vazios!");
            return;  // Não prosseguir com a inserção
        }

        // Verificar se os campos numéricos estão preenchidos corretamente
        if (TFarea.getText().isEmpty() || TFvalordiaria.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Área do imóvel e valor diário são obrigatórios!");
            return;
        }

        System.out.println("Campos validados, prosseguindo com o SQL...");

        // SQL para inserir dados
        String sql = "INSERT INTO propriedade (cnpj, email, telefone, endereco, cidade, estado, areaimovel, valordiaria, caracteristicas) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, cnpj.toString());              // CNPJ (BigInteger)
            stmt.setString(2, email);          // Email (String)
            stmt.setString(3, telefone);       // Telefone (String)
            stmt.setString(4, endereco);       // Endereco (String)
            stmt.setString(5, cidade);         // Cidade (String)
            stmt.setString(6, estado);         // Estado (String)
            stmt.setDouble(7, areaImovel);     // Area do Imovel (double)
            stmt.setDouble(8, valorDiaria);    // Valor da Diaria (double)
            stmt.setString(9, caracteristicas);// Caracteristicas (String)

            // Executa a inserção
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Propriedade cadastrada com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar propriedade: " + e.getMessage());
        }
}
    // Método para limpar os campos do formulário
    private void limparCampos() {
        TFcpfcnpj.setText("");  // Limpa o campo CNPJ
        TFemailcadastroimovel.setText("");  // Limpa o campo de Email
        TFtelefone.setText("");  // Limpa o campo Telefone
        TFendereco.setText("");  // Limpa o campo Endereço
        TFcidade.setText("");  // Limpa o campo Cidade
        TFestado.setText("");  // Limpa o campo Estado
        TFarea.setText("");  // Limpa o campo Área do Imóvel
        TFvalordiaria.setText("");  // Limpa o campo Valor da Diária
        TPcaracteristicas.setText("");  // Limpa o campo de Características
}

    
    /**
     * Creates new form ViewCadastroProp
     */
    public ViewCadastroProp() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel12 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        TFcpfcnpj = new javax.swing.JTextField();
        TFemailcadastroimovel = new javax.swing.JTextField();
        TFendereco = new javax.swing.JTextField();
        TFcidade = new javax.swing.JTextField();
        TFestado = new javax.swing.JTextField();
        TFarea = new javax.swing.JTextField();
        TFtelefone = new javax.swing.JTextField();
        TFvalordiaria = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TPcaracteristicas = new javax.swing.JTextPane();
        jLabel11 = new javax.swing.JLabel();
        BTsaircadasprop = new javax.swing.JButton();
        BTcadastrarprop = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();

        jLabel12.setText("jLabel12");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel2.setText("CPF/CNPJ :");

        jLabel1.setText("Email :");

        jLabel3.setText("Valor da Diaria :");

        jLabel4.setText("Telefone :");

        jLabel5.setText("Endereço ( Rua e Numero) :");

        jLabel6.setText("Cidade :");

        jLabel7.setText("Estado :");

        jLabel9.setText("Área do Imóvel (m2) :");

        jLabel10.setText("CARACTERISTICAS");

        jScrollPane1.setViewportView(TPcaracteristicas);

        jLabel11.setText("Descreva de forma simples e objetiva contendo as principais");

        BTsaircadasprop.setText("Sair");
        BTsaircadasprop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTsaircadaspropActionPerformed(evt);
            }
        });

        BTcadastrarprop.setText("Cadastrar");
        BTcadastrarprop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTcadastrarpropActionPerformed(evt);
            }
        });

        jLabel13.setText(" informaçoes do imóvel :");

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/5023254.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                            .addGap(152, 152, 152)
                            .addComponent(jLabel10)
                            .addGap(119, 119, 119))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(33, 33, 33)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel13)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel1)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel7)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel3)
                                            .addComponent(jLabel9))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(TFendereco)
                                            .addComponent(TFcpfcnpj)
                                            .addComponent(TFemailcadastroimovel)
                                            .addComponent(TFestado)
                                            .addComponent(TFcidade)
                                            .addComponent(TFtelefone)
                                            .addComponent(TFarea)
                                            .addComponent(TFvalordiaria, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel11)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(BTcadastrarprop, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(BTsaircadasprop, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(132, 132, 132)
                        .addComponent(jLabel14)))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(TFcpfcnpj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(TFemailcadastroimovel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TFtelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TFendereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TFcidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TFestado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TFarea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TFvalordiaria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(52, 52, 52)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTsaircadasprop, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BTcadastrarprop, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BTsaircadaspropActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTsaircadaspropActionPerformed
        ViewPrincipal principal = new ViewPrincipal();  // Cria a tela principal
        principal.setLocationRelativeTo(null);  // Centraliza a tela
        principal.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BTsaircadaspropActionPerformed

    private void BTcadastrarpropActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTcadastrarpropActionPerformed
        cadastrarPropriedade();
        limparCampos();
        ViewPrincipal principal = new ViewPrincipal();  // Cria a tela principal
        principal.setLocationRelativeTo(null);  // Centraliza a tela
        principal.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_BTcadastrarpropActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewCadastroProp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewCadastroProp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewCadastroProp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewCadastroProp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ViewCadastroProp cadastroprop = new ViewCadastroProp();
                cadastroprop.setLocationRelativeTo(null);
                cadastroprop.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTcadastrarprop;
    private javax.swing.JButton BTsaircadasprop;
    private javax.swing.JTextField TFarea;
    private javax.swing.JTextField TFcidade;
    private javax.swing.JTextField TFcpfcnpj;
    private javax.swing.JTextField TFemailcadastroimovel;
    private javax.swing.JTextField TFendereco;
    private javax.swing.JTextField TFestado;
    private javax.swing.JTextField TFtelefone;
    private javax.swing.JTextField TFvalordiaria;
    private javax.swing.JTextPane TPcaracteristicas;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
